import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { NbkUiComponent } from './app/nbk-ui/nbk-ui.component';
import { provideHttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  template: `
    <app-nbk-ui></app-nbk-ui>
  `,
  standalone: true,
  imports: [NbkUiComponent]
})
export class App {
}

bootstrapApplication(App, {
  providers: [
    provideHttpClient()
  ]
}).catch(err => console.error(err));