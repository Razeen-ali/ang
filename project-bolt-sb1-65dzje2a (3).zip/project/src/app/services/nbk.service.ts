import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin, of } from 'rxjs';
import { map, tap, catchError, mergeMap } from 'rxjs/operators';

export interface ADcheckResponse {
  status: 'EXIST' | 'NOT_EXIST';
}

export interface CSARResponse {
  IsAutoLogTouchpointEnable: boolean;
  IsFromOutlookSync: boolean;
  IsToOutSync: boolean;
  AssociateShortName: string;
}

export interface NBKrequirements {
  nbk: string;
  name: string;
  adGroup: boolean;
  autoLog: boolean;
  outFrom: boolean;
  outTo: boolean;
  bankingEws: boolean;
  hangfireJob: boolean;
  lastSync: string;
}

export interface EmailRequest {
  emailIds: string[];
}

@Injectable({
  providedIn: 'root'
})
export class NBKapi_call {
  private readonly AD_CHECK_API = 'https://usvmwebcmp01.sdi.corp.bankofamerica.com:8006/api/adcheck';
  private readonly CSAR_API = 'http://salesdesktop.bankofamerica.com:1512/CompassSalesService.svc/json/profiles/nbkid';
  private readonly EMAIL_TO_NBK_API = 'http://salesdesktop.bankofamerica.com:1512/CompassSalesService.svc/json/getNBKListfromEmails';

  constructor(private http: HttpClient) {}

  getNBKsFromEmails(emails: string[]): Observable<NBKrequirements[]> {
    const validEmails = emails.filter(email => email.toLowerCase().endsWith('@bofa.com'));
    if (validEmails.length === 0) {
      return of([]);
    }

    const payload: EmailRequest = { emailIds: validEmails };
    return this.http.post<string[]>(this.EMAIL_TO_NBK_API, payload).pipe(
      tap(response => {
        console.log('NBKs retrieved from emails:', response);
      }),
      mergeMap(nbks => {
        if (nbks.length === 0) return of([]);
        return forkJoin(nbks.map(nbk => this.getNBKrequirements(nbk)));
      }),
      catchError(error => {
        console.error('Error getting NBKs from emails:', error);
        return of([]);
      })
    );
  }

  checkADGroup(nbk: string): Observable<boolean> {
    const url = `${this.AD_CHECK_API}/${nbk}`;
    return this.http.get<ADcheckResponse>(url).pipe(
      tap(response => {
        console.log(`AD Group Check for NBK ${nbk}:`, response);
      }),
      map(response => response.status === 'EXIST'),
      catchError(error => {
        console.error(`Error in AD Group Check for NBK ${nbk}:`, error);
        return of(false);
      })
    );
  }

  checkCSAR(nbk: string): Observable<CSARResponse> {
    const url = `${this.CSAR_API}/${nbk}`;
    return this.http.get<CSARResponse>(url).pipe(
      tap(response => {
        console.log(`CSAR Check Response for NBK ${nbk}:`, response);
      }),
      catchError(error => {
        console.error(`Error in CSAR Check for NBK ${nbk}:`, error);
        return of({
          IsAutoLogTouchpointEnable: false,
          IsFromOutlookSync: false,
          IsToOutSync: false,
          AssociateShortName: 'Unknown'
        });
      })
    );
  }

  getNBKrequirements(nbk: string): Observable<NBKrequirements> {
    console.log(`Checking requirements for NBK ${nbk}`);
    return forkJoin({
      adGroup: this.checkADGroup(nbk),
      csarDetails: this.checkCSAR(nbk)
    }).pipe(
      map(results => ({
        nbk,
        name: results.csarDetails.AssociateShortName || 'Unknown',
        adGroup: results.adGroup,
        autoLog: results.csarDetails.IsAutoLogTouchpointEnable,
        outFrom: results.csarDetails.IsFromOutlookSync,
        outTo: results.csarDetails.IsToOutSync,
        bankingEws: Math.random() > 0.5,
        hangfireJob: Math.random() > 0.5,
        lastSync: new Date().toLocaleString()
      }))
    );
  }
}