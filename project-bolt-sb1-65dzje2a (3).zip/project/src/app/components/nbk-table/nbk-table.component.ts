import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

interface TableRow {
  nbk: string;
  requirement1: boolean;
  requirement2: boolean;
  requirement3: boolean;
}

@Component({
  selector: 'app-nbk-table',
  template: `
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>NBK</th>
            <th>Requirement 1</th>
            <th>Requirement 2</th>
            <th>Requirement 3</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let row of data">
            <td>{{ row.nbk }}</td>
            <td>{{ row.requirement1 }}</td>
            <td>{{ row.requirement2 }}</td>
            <td>{{ row.requirement3 }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  `,
  styleUrls: ['./nbk-table.component.css'],
  standalone: true,
  imports: [CommonModule]
})
export class NbkTableComponent {
  @Input() data: TableRow[] = [];
}