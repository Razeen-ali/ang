import { Component } from '@angular/core';

@Component({
  selector: 'app-nbk-sidebar',
  template: `
    <div class="sidebar">
      Outlook Sync
    </div>
  `,
  styleUrls: ['./nbk-sidebar.component.css'],
  standalone: true
})
export class NbkSidebarComponent {}