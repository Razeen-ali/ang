import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-nbk-input',
  template: `
    <div class="nbk-entry">
      <input 
        [(ngModel)]="value"
        (ngModelChange)="valueChange.emit($event)"
        placeholder="Enter NBK"
        type="text" 
      />
      <button 
        *ngIf="showRemoveButton" 
        (click)="onRemove.emit()" 
        class="remove-button"
      >&times;</button>
    </div>
  `,
  styleUrls: ['./nbk-input.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class NbkInputComponent {
  @Input() value: string = '';
  @Input() showRemoveButton: boolean = false;
  @Output() valueChange = new EventEmitter<string>();
  @Output() onRemove = new EventEmitter<void>();
}