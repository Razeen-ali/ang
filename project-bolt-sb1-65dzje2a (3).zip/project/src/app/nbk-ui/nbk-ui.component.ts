import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NBKapi_call, NBKrequirements } from '../services/nbk.service';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-nbk-ui',
  templateUrl: './nbk-ui.component.html',
  styleUrls: ['./nbk-ui.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class NbkUiComponent {
  nbkInput: string = '';
  tableData: NBKrequirements[] = [];
  readonly MAX_NBKS = 5;

  constructor(private nbkapi_call: NBKapi_call) {}

  getData(): void {
    const items = this.nbkInput
      .split(',')
      .map(item => item.trim())
      .filter(item => item !== '');

    if (items.length > this.MAX_NBKS) {
      alert(`Maximum ${this.MAX_NBKS} items allowed`);
      return;
    }

    const emailItems = items.filter(item => item.includes('@'));
    const nbkItems = items.filter(item => !item.includes('@'));

    // Process NBKs directly
    const nbkObservables = nbkItems.map(nbk => this.nbkapi_call.getNBKrequirements(nbk));
    
    // Process emails to get NBKs
    const emailObservable = this.nbkapi_call.getNBKsFromEmails(emailItems);

    // Combine both observables
    forkJoin([...nbkObservables, emailObservable]).subscribe({
      next: (results) => {
        console.log('All results:', results);
        this.tableData = results.flat();
      },
      error: (error) => {
        console.error('Error fetching data:', error);
        alert('Error fetching data. Please try again!');
      }
    });
  }

  clearAll(): void {
    console.log('Clearing all data');
    this.nbkInput = '';
    this.tableData = [];
  }

  getRequirementSymbol(value: boolean): string {
    return value ? '✓' : '✗';
  }
}